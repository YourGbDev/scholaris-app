// ─── Scholaris Design Toolkit ───────────────────────────────────────────────
// Figma plugin code.js — runs in the Figma sandbox

const BRAND = {
  colors: {
    bridgeGreen:      { r: 0.059, g: 0.302, b: 0.180 }, // #0F4D2E
    goldenOpportunity:{ r: 0.945, g: 0.706, b: 0.118 }, // #F1B41E
    navyTrust:        { r: 0.106, g: 0.227, b: 0.361 }, // #1B3A5C
    coralConnect:     { r: 1.000, g: 0.435, b: 0.349 }, // #FF6F59
    warmWhite:        { r: 0.980, g: 0.980, b: 0.973 }, // #FAFAF8
    white:            { r: 1.000, g: 1.000, b: 1.000 },
  },
  cornerRadius: 12,
  inputRadius: 10,
  buttonRadius: 50, // pill buttons
};

// Helper: hex to Figma RGB
function hex(h) {
  const n = parseInt(h.replace('#',''), 16);
  return { r: ((n>>16)&255)/255, g: ((n>>8)&255)/255, b: (n&255)/255 };
}

figma.showUI(__html__, { width: 320, height: 520, title: 'Scholaris Toolkit' });

figma.ui.onmessage = async (msg) => {

  // ── 1. APPLY BRAND STYLES TO SELECTION ──────────────────────────────────
  if (msg.type === 'apply-styles') {
    const nodes = figma.currentPage.selection;
    if (!nodes.length) {
      figma.notify('⚠️ Select at least one layer first.');
      return;
    }
    for (const node of nodes) {
      applyBrandStyle(node, msg.role);
    }
    figma.notify('✅ Scholaris styles applied!');
  }

  // ── 2. CREATE LOGIN SCREEN ───────────────────────────────────────────────
  if (msg.type === 'create-login') {
    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Semi Bold' });

    const frame = figma.createFrame();
    frame.name = 'Scholaris — Login';
    frame.resize(430, 932); // iPhone 16 & 17 Pro Max
    frame.fills = [{ type: 'SOLID', color: BRAND.colors.warmWhite }];
    frame.cornerRadius = 0;
    figma.currentPage.appendChild(frame);

    // Background accent blob (top)
    const blob = figma.createEllipse();
    blob.name = 'BG Accent';
    blob.resize(420, 420);
    blob.x = -60;
    blob.y = -160;
    blob.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen, opacity: 0.08 }];
    frame.appendChild(blob);

    // Wordmark — "Scholaris"
    const wordmark = figma.createText();
    wordmark.name = 'Wordmark';
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
    wordmark.fontName = { family: 'Inter', style: 'Bold' };
    wordmark.characters = 'Scholaris';
    wordmark.fontSize = 32;
    wordmark.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen }];
    wordmark.letterSpacing = { value: -0.5, unit: 'PIXELS' };
    wordmark.x = 0;
    wordmark.y = 0;
    wordmark.textAlignHorizontal = 'CENTER';
    wordmark.resize(430, 44);
    wordmark.y = 140;
    frame.appendChild(wordmark);

    // Tagline
    const tagline = figma.createText();
    tagline.name = 'Tagline';
    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    tagline.fontName = { family: 'Inter', style: 'Regular' };
    tagline.characters = 'Your scholarship, found.';
    tagline.fontSize = 14;
    tagline.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.6 }];
    tagline.textAlignHorizontal = 'CENTER';
    tagline.resize(430, 22);
    tagline.y = 192;
    frame.appendChild(tagline);

    // Welcome text
    const welcome = figma.createText();
    welcome.name = 'Welcome Heading';
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
    welcome.fontName = { family: 'Inter', style: 'Bold' };
    welcome.characters = 'Welcome back';
    welcome.fontSize = 24;
    welcome.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust }];
    welcome.x = 32;
    welcome.y = 240;
    frame.appendChild(welcome);

    const sub = figma.createText();
    sub.name = 'Welcome Sub';
    sub.fontName = { family: 'Inter', style: 'Regular' };
    sub.characters = 'Sign in to continue to Scholaris';
    sub.fontSize = 14;
    sub.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.55 }];
    sub.x = 32;
    sub.y = 272;
    frame.appendChild(sub);

    // Email input
    const emailField = createInputField('Email address', 32, 360, 366);
    frame.appendChild(emailField);

    // Password input
    const passField = createInputField('Password', 32, 430, 366);
    frame.appendChild(passField);

    // Forgot password
    const forgot = figma.createText();
    forgot.name = 'Forgot Password';
    await figma.loadFontAsync({ family: 'Inter', style: 'Semi Bold' });
    forgot.fontName = { family: 'Inter', style: 'Semi Bold' };
    forgot.characters = 'Forgot password?';
    forgot.fontSize = 13;
    forgot.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen }];
    forgot.x = 270;
    forgot.y = 498;
    frame.appendChild(forgot);

    // Sign In button
    const btn = createButton('Sign In', 32, 548, 366);
    frame.appendChild(btn);

    // Divider + social hint
    const dividerTxt = figma.createText();
    dividerTxt.name = 'Or divider';
    dividerTxt.fontName = { family: 'Inter', style: 'Regular' };
    dividerTxt.characters = 'or continue with';
    dividerTxt.fontSize = 13;
    dividerTxt.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.4 }];
    dividerTxt.textAlignHorizontal = 'CENTER';
    dividerTxt.resize(366, 20);
    dividerTxt.x = 32;
    dividerTxt.y = 628;
    frame.appendChild(dividerTxt);

    // Google outline button
    const googleBtn = createOutlineButton('Continue with Google', 32, 662, 366);
    frame.appendChild(googleBtn);

    // Sign up link
    const signupRow = figma.createText();
    signupRow.name = 'Sign Up Link';
    signupRow.fontName = { family: 'Inter', style: 'Regular' };
    signupRow.characters = "Don't have an account?  Sign up";
    signupRow.fontSize = 13;
    signupRow.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.55 }];
    signupRow.textAlignHorizontal = 'CENTER';
    signupRow.resize(366, 20);
    signupRow.x = 32;
    signupRow.y = 870;
    frame.appendChild(signupRow);

    // Center frame in viewport
    figma.viewport.scrollAndZoomIntoView([frame]);
    figma.notify('✅ Login screen created!');
  }

  // ── 3. CREATE SIGN UP SCREEN ────────────────────────────────────────────
  if (msg.type === 'create-signup') {
    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Semi Bold' });

    const frame = figma.createFrame();
    frame.name = 'Scholaris — Sign Up';
    frame.resize(430, 932); // iPhone 16 & 17 Pro Max
    frame.fills = [{ type: 'SOLID', color: BRAND.colors.warmWhite }];
    frame.cornerRadius = 0;
    figma.currentPage.appendChild(frame);

    // BG accent blob (top right)
    const blob = figma.createEllipse();
    blob.name = 'BG Accent';
    blob.resize(380, 380);
    blob.x = 120;
    blob.y = -140;
    blob.fills = [{ type: 'SOLID', color: BRAND.colors.goldenOpportunity, opacity: 0.07 }];
    frame.appendChild(blob);

    // Back arrow placeholder
    const back = figma.createRectangle();
    back.name = 'Back Button';
    back.resize(40, 40);
    back.x = 24;
    back.y = 60;
    back.cornerRadius = 50;
    back.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.08 }];
    frame.appendChild(back);

    // Wordmark
    const wordmark = figma.createText();
    wordmark.name = 'Wordmark';
    wordmark.fontName = { family: 'Inter', style: 'Bold' };
    wordmark.characters = 'Scholaris';
    wordmark.fontSize = 28;
    wordmark.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen }];
    wordmark.letterSpacing = { value: -0.5, unit: 'PIXELS' };
    wordmark.textAlignHorizontal = 'CENTER';
    wordmark.resize(430, 38);
    wordmark.y = 120;
    frame.appendChild(wordmark);

    // Heading
    const heading = figma.createText();
    heading.name = 'Heading';
    heading.fontName = { family: 'Inter', style: 'Bold' };
    heading.characters = 'Create your account';
    heading.fontSize = 24;
    heading.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust }];
    heading.x = 32;
    heading.y = 186;
    frame.appendChild(heading);

    const sub = figma.createText();
    sub.name = 'Subheading';
    sub.fontName = { family: 'Inter', style: 'Regular' };
    sub.characters = 'Start finding scholarships that match you';
    sub.fontSize = 14;
    sub.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.55 }];
    sub.x = 32;
    sub.y = 218;
    frame.appendChild(sub);

    // Full Name input
    const nameField = createInputField('Full name', 32, 270, 366);
    frame.appendChild(nameField);

    // Email input
    const emailField = createInputField('Email address', 32, 338, 366);
    frame.appendChild(emailField);

    // Password input
    const passField = createInputField('Password', 32, 406, 366);
    frame.appendChild(passField);

    // Confirm Password input
    const confirmField = createInputField('Confirm password', 32, 474, 366);
    frame.appendChild(confirmField);

    // Terms note
    const terms = figma.createText();
    terms.name = 'Terms Note';
    terms.fontName = { family: 'Inter', style: 'Regular' };
    terms.characters = 'By signing up, you agree to our Terms & Privacy Policy';
    terms.fontSize = 12;
    terms.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.45 }];
    terms.textAlignHorizontal = 'CENTER';
    terms.resize(366, 18);
    terms.x = 32;
    terms.y = 548;
    frame.appendChild(terms);

    // Create Account button
    const btn = createButton('Create Account', 32, 586, 366);
    frame.appendChild(btn);

    // Divider
    const dividerTxt = figma.createText();
    dividerTxt.name = 'Or divider';
    dividerTxt.fontName = { family: 'Inter', style: 'Regular' };
    dividerTxt.characters = 'or sign up with';
    dividerTxt.fontSize = 13;
    dividerTxt.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.4 }];
    dividerTxt.textAlignHorizontal = 'CENTER';
    dividerTxt.resize(366, 20);
    dividerTxt.x = 32;
    dividerTxt.y = 660;
    frame.appendChild(dividerTxt);

    // Google outline button
    const googleBtn = createOutlineButton('Continue with Google', 32, 694, 366);
    frame.appendChild(googleBtn);

    // Already have account link
    const loginRow = figma.createText();
    loginRow.name = 'Login Link';
    loginRow.fontName = { family: 'Inter', style: 'Regular' };
    loginRow.characters = 'Already have an account?  Sign in';
    loginRow.fontSize = 13;
    loginRow.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.55 }];
    loginRow.textAlignHorizontal = 'CENTER';
    loginRow.resize(366, 20);
    loginRow.x = 32;
    loginRow.y = 876;
    frame.appendChild(loginRow);

    figma.viewport.scrollAndZoomIntoView([frame]);
    figma.notify('✅ Sign Up screen created!');
  }

  // ── 4. CREATE COMPONENTS ─────────────────────────────────────────────────
  if (msg.type === 'create-components') {
    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Semi Bold' });

    let x = 0;

    // Primary Button
    const btn1 = createButton('Primary Button', x, 0, 200);
    btn1.name = '🟢 Btn/Primary';
    figma.currentPage.appendChild(btn1);
    x += 220;

    // Outline Button
    const btn2 = createOutlineButton('Outline Button', x, 0, 200);
    btn2.name = '⬜ Btn/Outline';
    figma.currentPage.appendChild(btn2);
    x += 220;

    // Input field
    const input = createInputField('Placeholder text', x, 0, 280);
    input.name = '📝 Input/Default';
    figma.currentPage.appendChild(input);
    x += 300;

    // Card
    const card = createScholarshipCard(x, 0);
    figma.currentPage.appendChild(card);
    x += 320;

    // Badge
    const badge = createBadge('Matched', x, 0);
    badge.name = '🏷 Badge/Matched';
    figma.currentPage.appendChild(badge);

    figma.viewport.scrollAndZoomIntoView(figma.currentPage.children);
    figma.notify('✅ Scholaris components created!');
  }

  if (msg.type === 'cancel') figma.closePlugin();
};

// ── HELPER: INPUT FIELD ──────────────────────────────────────────────────────
function createInputField(placeholder, x, y, width) {
  const field = figma.createFrame();
  field.name = `Input — ${placeholder}`;
  field.resize(width, 52);
  field.x = x;
  field.y = y;
  field.cornerRadius = BRAND.inputRadius;
  field.fills = [{ type: 'SOLID', color: BRAND.colors.white }];
  field.strokes = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.2 }];
  field.strokeWeight = 1.5;
  field.strokeAlign = 'INSIDE';

  const label = figma.createText();
  label.fontName = { family: 'Inter', style: 'Regular' };
  label.characters = placeholder;
  label.fontSize = 14;
  label.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.4 }];
  label.x = 16;
  label.y = 17;
  field.appendChild(label);

  return field;
}

// ── HELPER: PRIMARY BUTTON ───────────────────────────────────────────────────
function createButton(label, x, y, width) {
  const btn = figma.createFrame();
  btn.name = `Button — ${label}`;
  btn.resize(width, 52);
  btn.x = x;
  btn.y = y;
  btn.cornerRadius = BRAND.buttonRadius;
  btn.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen }];

  const txt = figma.createText();
  txt.fontName = { family: 'Inter', style: 'Bold' };
  txt.characters = label;
  txt.fontSize = 15;
  txt.fills = [{ type: 'SOLID', color: BRAND.colors.white }];
  txt.textAlignHorizontal = 'CENTER';
  txt.resize(width, 52);
  txt.y = 0;
  // vertically center via padding
  txt.textAlignVertical = 'CENTER';
  btn.appendChild(txt);

  return btn;
}

// ── HELPER: OUTLINE BUTTON ───────────────────────────────────────────────────
function createOutlineButton(label, x, y, width) {
  const btn = figma.createFrame();
  btn.name = `Button — ${label}`;
  btn.resize(width, 52);
  btn.x = x;
  btn.y = y;
  btn.cornerRadius = BRAND.buttonRadius;
  btn.fills = [{ type: 'SOLID', color: BRAND.colors.warmWhite }];
  btn.strokes = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.25 }];
  btn.strokeWeight = 1.5;
  btn.strokeAlign = 'INSIDE';

  const txt = figma.createText();
  txt.fontName = { family: 'Inter', style: 'Semi Bold' };
  txt.characters = label;
  txt.fontSize = 14;
  txt.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust }];
  txt.textAlignHorizontal = 'CENTER';
  txt.textAlignVertical = 'CENTER';
  txt.resize(width, 52);
  btn.appendChild(txt);

  return btn;
}

// ── HELPER: SCHOLARSHIP CARD ─────────────────────────────────────────────────
function createScholarshipCard(x, y) {
  const card = figma.createFrame();
  card.name = '📋 Card/Scholarship';
  card.resize(300, 160);
  card.x = x;
  card.y = y;
  card.cornerRadius = BRAND.cornerRadius;
  card.fills = [{ type: 'SOLID', color: BRAND.colors.white }];
  card.effects = [{
    type: 'DROP_SHADOW',
    color: { r: 0.106, g: 0.227, b: 0.361, a: 0.08 },
    offset: { x: 0, y: 4 },
    radius: 16,
    spread: 0,
    visible: true,
    blendMode: 'NORMAL',
  }];

  // Gold accent bar (left edge)
  const accent = figma.createRectangle();
  accent.name = 'Accent Bar';
  accent.resize(4, 120);
  accent.x = 0;
  accent.y = 20;
  accent.cornerRadius = 4;
  accent.fills = [{ type: 'SOLID', color: BRAND.colors.goldenOpportunity }];
  card.appendChild(accent);

  const title = figma.createText();
  title.fontName = { family: 'Inter', style: 'Bold' };
  title.characters = 'DOST-SEI Scholarship';
  title.fontSize = 15;
  title.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust }];
  title.x = 20;
  title.y = 20;
  card.appendChild(title);

  const org = figma.createText();
  org.fontName = { family: 'Inter', style: 'Regular' };
  org.characters = 'Department of Science & Technology';
  org.fontSize = 12;
  org.fills = [{ type: 'SOLID', color: BRAND.colors.navyTrust, opacity: 0.55 }];
  org.x = 20;
  org.y = 44;
  card.appendChild(org);

  const amount = figma.createText();
  amount.fontName = { family: 'Inter', style: 'Bold' };
  amount.characters = '₱40,000 / year';
  amount.fontSize = 18;
  amount.fills = [{ type: 'SOLID', color: BRAND.colors.bridgeGreen }];
  amount.x = 20;
  amount.y = 80;
  card.appendChild(amount);

  const deadline = figma.createText();
  deadline.fontName = { family: 'Inter', style: 'Regular' };
  deadline.characters = 'Deadline: Aug 31, 2025';
  deadline.fontSize = 12;
  deadline.fills = [{ type: 'SOLID', color: BRAND.colors.coralConnect }];
  deadline.x = 20;
  deadline.y = 110;
  card.appendChild(deadline);

  return card;
}

// ── HELPER: BADGE ────────────────────────────────────────────────────────────
function createBadge(label, x, y) {
  const badge = figma.createFrame();
  badge.name = `Badge — ${label}`;
  badge.resize(90, 28);
  badge.x = x;
  badge.y = y;
  badge.cornerRadius = 50;
  badge.fills = [{ type: 'SOLID', color: BRAND.colors.goldenOpportunity, opacity: 0.18 }];

  const txt = figma.createText();
  txt.fontName = { family: 'Inter', style: 'Semi Bold' };
  txt.characters = label;
  txt.fontSize = 12;
  txt.fills = [{ type: 'SOLID', color: hex('#9A7010') }];
  txt.textAlignHorizontal = 'CENTER';
  txt.textAlignVertical = 'CENTER';
  txt.resize(90, 28);
  badge.appendChild(txt);

  return badge;
}

// ── HELPER: APPLY BRAND STYLE TO A NODE ──────────────────────────────────────
function applyBrandStyle(node, role) {
  const colorMap = {
    primary:    BRAND.colors.bridgeGreen,
    accent:     BRAND.colors.goldenOpportunity,
    secondary:  BRAND.colors.navyTrust,
    highlight:  BRAND.colors.coralConnect,
    background: BRAND.colors.warmWhite,
  };
  const color = colorMap[role] || BRAND.colors.bridgeGreen;

  if ('fills' in node) {
    node.fills = [{ type: 'SOLID', color }];
  }
  if ('cornerRadius' in node && !('text' in node)) {
    node.cornerRadius = BRAND.cornerRadius;
  }
}
